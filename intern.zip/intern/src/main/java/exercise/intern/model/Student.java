package exercise.intern.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {

    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    private int studentID;

    private String fullName;
    private float avgMark;

    public Student(String fullName, float avgMark) {

        super();
        this.fullName = fullName;
        this.avgMark = avgMark;

    }

    /**
     * @return the studentID
     */
    public int getStudentID() { return studentID; }

    /**
     * @return the fullName
     */
    public String getFullName() { return fullName; }

    /**
     * @param fullName the fullName to set
     */
    public void setFullName( String fullName ) { this.fullName = fullName; }

    /**
     * @return the avgMark
     */
    public float getAvgMark() { return avgMark; }

    /**
     * @param avgMark the avgMark to set
     */
    public void setAvgMark( float avgMark ) { this.avgMark = avgMark; }

}
