
package exercise.intern.service;

import java.util.List;

import exercise.intern.model.Student;

public class StudentServiceImp implements StudentService {

    @Override
    public List<Student> getAllUser( String fullname ) {

        return null;

    }

    @Override
    public void saveStudent( Student student ) {}

}
