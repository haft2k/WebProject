
package exercise.intern.service;

import java.util.List;

import exercise.intern.model.Student;

public interface StudentService {
    
    List<Student> getAllUser(String fullname);
    
    void saveStudent(Student student);
    
}

