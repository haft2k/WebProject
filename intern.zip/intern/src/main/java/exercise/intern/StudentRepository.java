/*
 * GumBox Inc
 * (c) 2022 GumBox Inc. Viet Nam
 *
 */
package exercise.intern;

import org.springframework.data.jpa.repository.JpaRepository;

import exercise.intern.model.Student;



public interface StudentRepository extends JpaRepository<Student, Long> {

}

