package net.com.intern.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table( name = "student" )
public class Student {

    @Id
    @GeneratedValue( strategy = GenerationType.IDENTITY )
    private int id;

    @Column( name = "full_name" )
    private String fullName;

    @Column( name = "avg_point" )
    private float avgPoint;

    public Student() {}

    public Student(String fullName, float avgPoint) {

        super();
        this.fullName = fullName;
        this.avgPoint = avgPoint;

    }

    public int getId() { return id; }

    public String getFullName() { return fullName; }

    public void setFullName( String fullName ) { this.fullName = fullName; }

    public float getAvgPoint() { return avgPoint; }

    public void setAvgPoint( float avgPoint ) { this.avgPoint = avgPoint; }

}