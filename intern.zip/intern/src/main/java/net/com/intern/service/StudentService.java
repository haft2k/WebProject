package net.com.intern.service;

import java.util.List;

import org.springframework.stereotype.Service;

import net.com.intern.model.Student;

@Service
public interface StudentService {

    List<Student> getAllStudent();

    List<Student> findByName( String fullName );
    
    List<Student> lstStudentGreaterAvg();
    
}
