
package net.com.intern.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import net.com.intern.model.Student;
import net.com.intern.service.StudentServiceImp;

@Controller
public class UserController {

    @Autowired
    private StudentServiceImp studentServiceImp;

    @RequestMapping( "/" )
    public String viewHomePage( Model model, @Param("full_name") String fullname) {
         List<Student> lstStudent = studentServiceImp.findByName(fullname);
         model.addAttribute("lstStudent", lstStudent);
         model.addAttribute("full_name", fullname);
         
         return "index";
    }

}
