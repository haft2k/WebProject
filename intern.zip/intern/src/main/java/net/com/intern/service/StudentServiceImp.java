
package net.com.intern.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.com.intern.model.Student;
import net.com.intern.repository.StudentRepository;

@Service
public class StudentServiceImp implements StudentService {

    @Autowired
    private StudentRepository studentRepository;

    @Override
    public List<Student> getAllStudent() { return studentRepository.findAll(); }

    @Override
    public List<Student> findByName( String fullName ) {

        return studentRepository.findByName(fullName);

    }

    @Override
    public List<Student> lstStudentGreaterAvg() {

        return studentRepository.findByAvgPoint();

    }

}
