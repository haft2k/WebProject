package com.example.demo.service;

import java.util.List;

import com.example.demo.model.Receipt;
import com.example.demo.model.Ticket;

public class UserServiceImp implements UserService {

    @Override
    public List<Receipt> getAllReceipt() { return null; }

    @Override
    public List<Ticket> getAllTicket() { return null; }

}
