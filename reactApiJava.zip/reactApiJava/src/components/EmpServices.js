import axios from "axios";

const EMP_API_BASE_URL = "http://localhost:8080/api/v1/employees";

class EmpServices{
    getAllEmps(){
        return axios.get(EMP_API_BASE_URL);
    }

    addNewEmp(employee){
        return axios.post(EMP_API_BASE_URL, employee);
    }

}

export default new EmpServices();