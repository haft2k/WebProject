import React, { Component } from 'react'

export default class EmpDetail extends Component {
  render() {
    return (
      <div>EmpDetail</div>
    )
  }
}
