import React, { Component } from 'react'

export default class EmpAddNew extends Component {
  render() {
    return (
      <div>EmpAddNew</div>
    )
  }
}
