import React, { Component } from 'react'

export default class EmpDel extends Component {
  render() {
    return (
      <div>EmpDel</div>
    )
  }
}
