import React, { Component } from 'react'
import EmpServices from './EmpServices'
import { Link } from "react-router-dom";

export default class Home extends Component {

    constructor(props) {
        super(props);
        this.state = {
            employees: []
        }
    }

    componentDidMount() {

        EmpServices.getAllEmps().then((res) => {
            this.setState({ employees: res.data });
            //console.log("OK");
        })

    }
    render() {
        return (
            <div className="container">
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#ID</th>
                            <th scope="col">First Name</th>
                            <th scope="col">Last Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Detail</th>
                            <th scope="col">Edit</th>
                            <th scope="col">Delete</th>
                        </tr>
                    </thead>
                    <tbody class="table-group-divider">
                        {this.state.employees.map(employee =>
                           
                        <tr>
                            <td scope="row" key={employee.id}>{employee.id}</td>
                            <td>{employee.fitstname}</td>
                            <td>{employee.lastname}</td>
                            <td>{employee.email}</td>
                            <td>
                                <Link to={`/detail?${employee.id}`}><i class="bi bi-pencil"></i></Link>
                            </td>

                            <td>
                                <a href={`/edit?id=${employee.id}`}><i class="bi bi-pencil"></i></a>
                            </td>
                            <td>
                                <a href={`/delete?id=${employee.id}`}> <i class="bi bi-trash"></i></a>
                            </td>

                        </tr>
                        )}

                    </tbody>
                </table>
            </div>
        )
    }
}
