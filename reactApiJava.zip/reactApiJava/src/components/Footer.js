import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div class="bg-dark text-center text-white mt-5">All Rights Reversed by JavaGuides</div>
    )
  }
}
