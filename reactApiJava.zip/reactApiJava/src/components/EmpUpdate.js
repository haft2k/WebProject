import React, { Component } from 'react'

export default class EmpUpdate extends Component {
  render() {
    return (
      <div>EmpUpdate</div>
    )
  }
}
