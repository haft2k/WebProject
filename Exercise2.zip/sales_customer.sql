-- MySQL dump 10.13  Distrib 8.0.29, for Win64 (x86_64)
--
-- Host: localhost    Database: sales
-- ------------------------------------------------------
-- Server version	8.0.29

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Karlotte Gallandre','kgallandre0@4shared.com','31505 Truax Trail'),(2,'Dario Corde','dcorde1@imgur.com','716 Lakeland Road'),(3,'Maxwell Astell','mastell2@cdbaby.com','95841 Magdeline Plaza'),(4,'Devonna Lording','dlording3@theguardian.com','6471 West Lane'),(5,'Mora Gladbach','mgladbach4@irs.gov','07 Stuart Parkway'),(6,'Xaviera Corde','xcorde5@slate.com','7181 8th Junction'),(7,'Ebenezer Sweetman','esweetman6@jimdo.com','59 Farwell Center'),(8,'Whittaker Mc Caughen','wmc7@ucoz.com','31 Corben Hill'),(9,'Mabelle Hadwick','mhadwick8@hao123.com','85854 Corry Pass'),(10,'Marty Novakovic','mnovakovic9@goo.ne.jp','1 Hoffman Parkway'),(11,'Randolph Phizaclea','rphizacleaa@cyberchimps.com','87 Ronald Regan Plaza'),(12,'Ariella Elstone','aelstoneb@ihg.com','84936 Ruskin Center'),(13,'Hymie Snookes','hsnookesc@gmpg.org','36691 Old Gate Lane'),(14,'Mae Iacovucci','miacovuccid@businesswire.com','467 Tennyson Drive'),(15,'Hildy McGilvray','hmcgilvraye@nasa.gov','33 Golf Course Center'),(16,'Gretchen Peacey','gpeaceyf@engadget.com','446 Bultman Avenue'),(17,'Cazzie Monier','cmonierg@furl.net','3 Autumn Leaf Point'),(18,'Freddie Aucutt','faucutth@cisco.com','72 Pawling Street'),(19,'Jacquette Hukin','jhukini@ycombinator.com','3 Cherokee Parkway'),(20,'Jacquie Dumke','jdumkej@japanpost.jp','45366 Cascade Trail');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-02 15:34:04
