/*
 * GumBox Inc
 * (c) 2022 GumBox Inc. Viet Nam
 *
 * This software is the confidential and proprietary
 * information of GumBox, Inc
 * ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with GumBox
 */
package com.dao;

import java.util.List;

import com.model.Category;

/**
 *
 * @author falcon
 */
public class CategoryDAOImp implements CategoryDAO {

	@Override
	public List<Category> selectAllCategories() { return null; }

	@Override
	public Category selectCategoryByID( int ID ) { return null; }

	@Override
	public void insertCategory( Category category ) {}

	@Override
	public boolean deleteCategoryByID( int ID ) { return false; }

	@Override
	public boolean updateTodo( Category category ) { return false; }

}
