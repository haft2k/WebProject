/*
 * GumBox Inc
 * (c) 2022 GumBox Inc. Viet Nam
 *
 * This software is the confidential and proprietary
 * information of GumBox, Inc
 * ("Confidential Information"). You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into with GumBox
 */
package com.dao;

import java.util.List;

import com.model.Category;

/**
 *
 * @author falcon
 */
public interface CategoryDAO {

	public List<Category> selectAllCategories();

	public Category selectCategoryByID( int ID );

	public void insertCategory( Category category );

	public boolean deleteCategoryByID( int ID );

	public boolean updateTodo( Category category );

}
