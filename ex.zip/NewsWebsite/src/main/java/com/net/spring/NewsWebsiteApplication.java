package com.net.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsWebsiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsWebsiteApplication.class, args);
	}

}
