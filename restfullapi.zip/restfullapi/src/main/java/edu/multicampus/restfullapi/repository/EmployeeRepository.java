package edu.multicampus.restfullapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.multicampus.restfullapi.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

}
