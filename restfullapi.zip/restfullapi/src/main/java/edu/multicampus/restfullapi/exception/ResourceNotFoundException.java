package edu.multicampus.restfullapi.exception;

public class ResourceNotFoundException extends RuntimeException {
	private static final long serialVersionID = 1L;

	public ResourceNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
}
