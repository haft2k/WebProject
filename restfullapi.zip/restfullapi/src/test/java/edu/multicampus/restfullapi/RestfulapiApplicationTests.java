package edu.multicampus.restfullapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestfulapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
